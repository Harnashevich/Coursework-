//
//  AddNewPartVC.swift
//  MyProject
//
//  Created by garnoshevich on 15.09.21.
//

import UIKit

final class AddNewServiceVC: UIViewController,
                             UITextViewDelegate,
                             UITextFieldDelegate {
    
    @IBOutlet private weak var nameServiceTextField: UITextField!
    @IBOutlet private weak var mileageServiceTextField: UITextField!
    @IBOutlet private weak var dateServiceTextField: UITextField!
    @IBOutlet private weak var mileageNextServiceTextField: UITextField!
    @IBOutlet private weak var dateNextServiceTextField: UITextField!
    @IBOutlet private weak var detailsTextView: UITextView!
    @IBOutlet private weak var serviceView: UIView!
    @IBOutlet private weak var nextServiceView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getDelegate()
        setupDateTextField()
        setupDateNextTextField()
        setupDesign()
        setupNotificationCenter()
        setupMileage()
    }
    
    var carInfo: Car!
    
    // MARK: - Передача пробега в поле "обслуживание было выполнено"
    func setupMileage() {
        mileageServiceTextField.text = String(carInfo.mileage)
    }
    
    // MARK: - Поднятие detailsTextView на уровень клавиатуры
    func setupNotificationCenter() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWillShow(notification: NSNotification) {
        if detailsTextView.isFirstResponder {
            if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
                if self.view.frame.origin.y == 0 {
                    self.view.frame.origin.y -= keyboardSize.height
                }
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    // MARK: - Установка дизайна
    func setupDesign() {
        serviceView.layer.cornerRadius = serviceView.frame.height / 10
        nextServiceView.layer.cornerRadius = nextServiceView.frame.height / 10
        detailsTextView.layer.cornerRadius = detailsTextView.frame.height / 16
        serviceView.layer.borderWidth = 1
        nextServiceView.layer.borderWidth = 1
        detailsTextView.layer.borderWidth = 1
        serviceView.layer.borderColor = .init(red: 1, green: 0, blue: 0, alpha: 1)
        nextServiceView.layer.borderColor = .init(red: 0, green: 1, blue: 0, alpha: 1)
        detailsTextView.layer.borderColor = .init(red: 0, green: 0, blue: 1, alpha: 0.5)
        
    }
    
    
    // MARK: - Делегаты
    func getDelegate() {
        nameServiceTextField.delegate = self
        detailsTextView.delegate = self
        mileageServiceTextField.delegate = self
        mileageNextServiceTextField.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           print(#function)
           textField.resignFirstResponder()
           return true
       }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var maxLength = Int()

        switch textField {
        case nameServiceTextField: maxLength = 40
        case mileageServiceTextField : maxLength = 6
        case mileageNextServiceTextField: maxLength = 6
        default: break
        }
        
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        
        return newString.length <= maxLength
    }
    // убрать клавиатуру при нажатии в пустую область
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        nameServiceTextField.resignFirstResponder()
        mileageServiceTextField.resignFirstResponder()
        mileageNextServiceTextField.resignFirstResponder()
        detailsTextView.resignFirstResponder()
    }
    
    // MARK: - Сохранение информации в CoreData
    @IBAction func saveButtonDidTap() {
        if nameServiceTextField.text!.isEmpty {
            return
        }
            
        guard let name = nameServiceTextField.text,
              let mileageStr = mileageServiceTextField.text,
              let mileage = Int32(mileageStr),
              let dateService = serviceDatePicker,
              let detaNextService = serviceNextDatePicker,
              let mileageNextStr = mileageNextServiceTextField.text,
              let mileageNext = Int32(mileageNextStr),
              let details = detailsTextView.text
              
        else { return }

        let newService = Service(context: CoreDataService.shared.managedObjectContext)
        newService.nameService = name
        newService.mileageService = mileage
        newService.mileageNextService = mileageNext + mileage
        newService.dateService = dateService.date
        newService.dateNextService = detaNextService.date
        newService.details = details
        newService.car = carInfo
        CoreDataService.shared.saveContext()
    
        dismiss(animated: true)
    }
    
    // MARK: - Кнопка отмены
    @IBAction func cancelDidTapped() {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - DatePicker вместо клавиатуры
    var serviceDatePicker: UIDatePicker!
    private func setupDateTextField() {
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        
        dateServiceTextField.inputAccessoryView = toolBar
        toolBar.setItems([doneBtn], animated: true)
        
       
        serviceDatePicker = UIDatePicker()
        serviceDatePicker.datePickerMode = .date
        
        let yearAgo = Calendar.current.date(byAdding: .year, value: -41, to: Date())
        let yearLater = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        
        serviceDatePicker.minimumDate = yearAgo
        serviceDatePicker.maximumDate = yearLater
        
        if #available(iOS 13.4, *) {
            serviceDatePicker.preferredDatePickerStyle = .wheels
        }
        dateServiceTextField.inputView = serviceDatePicker
        serviceDatePicker.addTarget(self,
                                action: #selector(datePickerDidChange(sender:)), for: .valueChanged)
    }
    
    @objc func donePressed() {
        let selecterDate = serviceDatePicker.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMMM yyyy"
        dateServiceTextField.text = dateFormatter.string(from: selecterDate)
        self.view.endEditing(true)
    }
    
    @objc func datePickerDidChange(sender: UIDatePicker) {
        let selecterDate = sender.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMMM yyyy"
        dateServiceTextField.text = dateFormatter.string(from: selecterDate)
    }
    
    
    var serviceNextDatePicker: UIDatePicker!
    private func setupDateNextTextField() {
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(doneNextPressed))
        
        dateNextServiceTextField.inputAccessoryView = toolBar
        toolBar.setItems([doneBtn], animated: true)
        
       
        serviceNextDatePicker = UIDatePicker()
        serviceNextDatePicker.datePickerMode = .date
        
        let yearAgo = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        let yearLater = Calendar.current.date(byAdding: .year, value: +10, to: Date())
        
        serviceNextDatePicker.minimumDate = yearAgo
        serviceNextDatePicker.maximumDate = yearLater
        
        if #available(iOS 13.4, *) {
            serviceNextDatePicker.preferredDatePickerStyle = .wheels
        }
        dateNextServiceTextField.inputView = serviceNextDatePicker
        serviceNextDatePicker.addTarget(self,
                                action: #selector(datePickerNextDidChange(sender:)), for: .valueChanged)
    }
    
    // MARK: - Кнопка Done в DatePicker
    @objc func doneNextPressed() {
        let selecterDate = serviceNextDatePicker.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMMM yyyy"
        dateNextServiceTextField.text = dateFormatter.string(from: selecterDate)
        self.view.endEditing(true)
    }
    
    @objc func datePickerNextDidChange(sender: UIDatePicker) {
        let selecterDate = sender.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMMM yyyy"
        dateNextServiceTextField.text = dateFormatter.string(from: selecterDate)
    }

}



