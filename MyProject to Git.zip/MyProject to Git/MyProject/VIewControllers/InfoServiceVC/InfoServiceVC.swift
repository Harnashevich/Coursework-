//
//  InfoPartVC.swift
//  MyProject
//
//  Created by garnoshevich on 15.09.21.
//

import UIKit

final class InfoServiceVC: UIViewController {
    
    @IBOutlet private weak var nameServiceTextField: UILabel!
    @IBOutlet private weak var mileageServiceTextField: UILabel!
    @IBOutlet private weak var dateServiceTextField: UILabel!
    @IBOutlet private weak var mileageNextServiceTextField: UILabel!
    @IBOutlet private weak var dateNextServiceTextField: UILabel!
    @IBOutlet private weak var detailsTextView: UITextView!
    @IBOutlet private weak var serviceView: UIView!
    @IBOutlet private weak var nextServiceView: UIView!
    @IBOutlet private weak var openSiteButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupServiceInfo()
        setupDesign()
    }
    
    var infoService: Service!
    
    // MARK: - Кнопака перехода на сайт
    
    func goToUrl(string: String) {
        if let url = URL(string: string) {
              UIApplication.shared.open(url, options: [:]) }
    }
    
    @IBAction func openSite(sender: AnyObject) {
        
        let alert = UIAlertController(title: "Магазины",
                                        message: "Выберите магазин для заказа",
                                        preferredStyle: .alert)
        
        let remzonaAction = UIAlertAction(title: "remzona.by",
                                       style: .default) {_ in
            self.goToUrl(string: "https://remzona.by/catalog")
        }
        
        let autoostrovAction = UIAlertAction(title: "autoostrov.by",
                                       style: .default) {_ in
            self.goToUrl(string: "https://autoostrov.by")
        }
        
        let zapAction = UIAlertAction(title: "zap.by",
                                       style: .default) {_ in
            self.goToUrl(string: "https://zap.by")
        }
        
        let azaAction = UIAlertAction(title: "aza.by",
                                       style: .default) {_ in
            self.goToUrl(string: "https://aza.by")
        }
        
        let auto1Action = UIAlertAction(title: "auto1.by",
                                       style: .default) {_ in
            self.goToUrl(string: "https://auto1.by")
        }
        
        let canselAction = UIAlertAction(title: "Отмена", style: .cancel) { _ in }
        
        alert.addAction(remzonaAction)
        alert.addAction(autoostrovAction)
        alert.addAction(zapAction)
        alert.addAction(azaAction)
        alert.addAction(auto1Action)
        alert.addAction(canselAction)
        
        
            self.present(alert, animated: true, completion: nil)
    }
    
    
    
    // MARK: - Установка дизайна
    func setupDesign() {
        detailsTextView.layer.cornerRadius = detailsTextView.frame.height / 6
        nameServiceTextField.layer.masksToBounds = true
        nameServiceTextField.layer.cornerRadius = 10
        nameServiceTextField.layer.borderWidth = 3
        nameServiceTextField.layer.borderColor = .init(red: 80/255, green: 80/255, blue: 80/255, alpha: 0.3)
        serviceView.layer.cornerRadius = serviceView.frame.height / 10
        nextServiceView.layer.cornerRadius = nextServiceView.frame.height / 10
        detailsTextView.layer.cornerRadius = detailsTextView.frame.height / 16
        serviceView.layer.borderWidth = 1
        nextServiceView.layer.borderWidth = 1
        detailsTextView.layer.borderWidth = 1
        serviceView.layer.borderColor = .init(red: 1, green: 0, blue: 0, alpha: 1)
        nextServiceView.layer.borderColor = .init(red: 0, green: 0, blue: 1, alpha: 1)
        detailsTextView.layer.borderColor = .init(red: 0, green: 0, blue: 1, alpha: 0.5)
        openSiteButton.layer.cornerRadius = openSiteButton.frame.height / 4
        
    }
    // MARK: - Передача информации в лейбы
    func setupServiceInfo() {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "dd MMMM yyyy"
        
        nameServiceTextField.text = infoService.nameService
        mileageServiceTextField.text = String(infoService.mileageService)
        dateServiceTextField.text = dateformatter.string(from: infoService.dateService ?? Date())
        mileageNextServiceTextField.text = String(infoService.mileageNextService)
        dateNextServiceTextField.text = dateformatter.string(from: infoService.dateNextService ?? Date())
        detailsTextView.text = infoService.details
    }
}
