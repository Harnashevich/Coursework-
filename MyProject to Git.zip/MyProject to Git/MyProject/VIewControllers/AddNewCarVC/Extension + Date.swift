//
//  Extension + Date.swift
//  MyProject
//
//  Created by garnoshevich on 7.10.21.
//

import Foundation

extension Date {
    
    static func getYearNow() -> Int {
    
    let calendar = Calendar.current
    let date = Date()
        
    let year = calendar.component(.year, from: date)
    
    return Int(year)
    }
}
 // Дополнение к классу Date для возвращения года с формате Int


