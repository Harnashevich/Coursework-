//
//  AddNewCarVC.swift
//  MyProject
//
//  Created by garnoshevich on 15.09.21.
//

import UIKit

final class AddNewCarVC: UIViewController,
                   UINavigationControllerDelegate,
                   UIImagePickerControllerDelegate,
                   UIPickerViewDataSource,
                   UIPickerViewDelegate,
                   CarBrandsListVCDelegate,
                   UITextFieldDelegate {
    
    func sendCarBrand(brand: Brands) {
        carBrandTextField.text = brand.name
        carImageView.loadImageUrl(by: brand.logo, completion: { })
    }
    
    @IBOutlet private weak var carImageView: UIImageView!
    @IBOutlet private weak var carBrandTextField: UITextField!
    @IBOutlet private weak var carModelField: UITextField!
    @IBOutlet private weak var carYearTextField: UITextField!
    @IBOutlet private weak var carMileageTextField: UITextField!
    @IBOutlet private weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDateTextField()
        getDelegate()
        carYearTextField.inputView = picker
        carModelField.autocorrectionType = .no // отключение предиктивного ввода
    }
    // MARK: - Подписка на делегаты
    func getDelegate() {
        picker.dataSource = self
        picker.delegate = self
        carMileageTextField.delegate = self
        carModelField.delegate = self
        carYearTextField.delegate = self
    }
    
    // MARK: - Методы делегатов
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        carModelField.resignFirstResponder()
        carMileageTextField.resignFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var maxLength = Int()

        switch textField {
        case carMileageTextField: maxLength = 6
        case carModelField : maxLength = 20
        default: break
        }
        
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        
        return newString.length <= maxLength
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        errorLabel.alpha = 0
        // При начале редактированки логтоип ошибки становистя прозрачным
    }
    
    // MARK: - Сохранение в CodeData (лейба заполните все поля)
    @IBAction func saveButtonDidTap() {
        if carModelField.text!.isEmpty || carBrandTextField .text!.isEmpty || carYearTextField.text!.isEmpty || carMileageTextField.text!.isEmpty {
            errorLabel.alpha = 1
            errorLabel.text = "✖︎ Заполните все поля"
            errorLabel.textColor = .white
            errorLabel.backgroundColor = .systemRed
            errorLabel.layer.masksToBounds = true
            errorLabel.layer.cornerRadius = 8
            return // Блок чтобы все поля заполнили
        }
        
        guard let brand = carBrandTextField.text,
              let model = carModelField.text,
              let year = carYearTextField.text,
              let mileageStr = carMileageTextField.text,
              let mileage = Int32(mileageStr)

        else { return }

        let newCar = Car(context: CoreDataService.shared.managedObjectContext)
        newCar.brand = brand
        newCar.model = model
        newCar.year = year
        newCar.mileage = mileage
        
        CoreDataService.shared.saveContext()
    
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - Кнопка отмены
    @IBAction func cancelDidTapped() {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - Открытие страницы с брендами
    @IBAction func openBrandsList() {
        errorLabel.alpha = 0
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let nextVC = storyboard.instantiateViewController(withIdentifier: "CarBrandsListVC") as? CarBrandsListVC {
            nextVC.delegate = self
            present(nextVC, animated: true, completion: nil)
            
        }
    }
  
    // MARK: - Выбор года с PickerView
    var picker = UIPickerView()
    var data = Array(1980...Date.getYearNow()).map{ String($0)}
     
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return data.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        carYearTextField.text = data[row]
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return data[row]
    }
    
    private func setupDateTextField() {
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        
        carYearTextField.inputAccessoryView = toolBar
        toolBar.setItems([doneBtn], animated: true)
    }
    @objc func donePressed() {
        self.view.endEditing(true)
    }
    
}

   

