//
//  UIImageView+Utils.swift
//  MyProject
//
//  Created by garnoshevich on 22.09.21.
//

import UIKit

extension UIImageView {
    
    func loadImageUrl(by url: String, completion: @escaping () -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            if let imageUrl = URL(string: url),
               let imageData = try? Data(contentsOf: imageUrl),
               let image = UIImage(data: imageData) {
                DispatchQueue.main.async { [weak self] in
                    self?.image = image
                    completion()
                }
            }
        }
    }
    
}
