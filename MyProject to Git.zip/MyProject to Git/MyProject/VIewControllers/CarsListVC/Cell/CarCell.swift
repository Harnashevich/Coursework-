//
//  CarsListCell.swift
//  MyProject
//
//  Created by garnoshevich on 15.09.21.
//

import UIKit

final class CarCell: UITableViewCell {

    static let identifier = "CarCell"
    static let rowHeight: CGFloat = 200
    
    @IBOutlet weak var carImageView: UIImageView!
    @IBOutlet weak var carBrandLabel: UILabel!
    @IBOutlet weak var carModelLabel: UILabel!
    @IBOutlet weak var carMileageLabel: UILabel!
    @IBOutlet weak var carYearLabel: UILabel!
    @IBOutlet weak var cellView: UIView!

}
