//
//  CarsListVC.swift
//  MyProject
//
//  Created by garnoshevich on 15.09.21.
//

import UIKit
import CoreData

final class CarsListVC: UIViewController,
                  UITableViewDelegate,
                  UITableViewDataSource,
                  NSFetchedResultsControllerDelegate {
    
    
    @IBOutlet  weak var editButton: UIBarButtonItem!
    @IBOutlet  weak var carsTableView: UITableView!
    @IBOutlet private weak var editDoneButton:UIBarButtonItem!
    
    private var cars = [Car]() {
        didSet {
            carsTableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        carsTableView.delegate = self
        carsTableView.dataSource = self
        setupFetchedResultController()
        loadAllCar()
    }
    

    // MARK: - Инициализация ячеек
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cars.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CarCell.identifier, for: indexPath) as? CarCell  else { return UITableViewCell() }
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy"
        
        cell.cellView.layer.cornerRadius = cell.cellView.frame.height / 6
        cell.layer.borderColor = UIColor.white.cgColor
        cell.layer.borderWidth = 1
        cell.carMileageLabel.layer.borderWidth = 0.3
        cell.carMileageLabel.layer.cornerRadius =  cell.carMileageLabel.frame.size.height / 3
        
        cell.carBrandLabel.text = cars[indexPath.row].brand
        cell.carModelLabel.text = cars[indexPath.row].model
        cell.carYearLabel.text = cars[indexPath.row].year
        cell.carMileageLabel.text = String(cars[indexPath.row].mileage)
//        cell.carImageView.image = cars[indexPath.row].photo
    
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        openInfo(with: cars[indexPath.row])
    }
    
    private func openInfo(with info: Car) {
        if let nextVC = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(identifier: "ServiceListVC") as? ServiceListVC {
            nextVC.infoCar = info
            navigationController?.pushViewController(nextVC, animated: true)
        }
    }
    // Хидер
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Список добавленных авто:"
    }
    
    func tableView(_ tableView: UITableView, shouldShowMenuForRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CarCell.rowHeight
    }
    
    // MARK: - Отчистка списка
    @IBAction func deleteCars() {
        let alert = UIAlertController(title: "Отчистка списка",
                                      message: "Вы действительн хотите удалить все авто из списка?",
                                      preferredStyle: .actionSheet)
        
        let saveAction = UIAlertAction(title: "Удалить",
                                       style: .destructive) { action in
            let context = CoreDataService.shared.managedObjectContext
            let fetchRequest: NSFetchRequest<Car> = Car.fetchRequest()
            if let objects = try? context.fetch(fetchRequest) {
                for object in objects {
                    context.delete(object)
                }
            }
            do {
                try context.save()
            } catch let error as NSError {
                print(error.localizedDescription)
            }
            self.carsTableView.reloadData()
        }
        
        let canselAction = UIAlertAction(title: "Отмена", style: .default) { _ in }
        
        alert.addAction(saveAction)
        alert.addAction(canselAction)
        
        present(alert, animated: true, completion: nil)
    }
    
  
    // MARK: - CoreData
    private var fetchedResultController: NSFetchedResultsController<Car>!
    
    private func setupFetchedResultController() {
        let request =  NSFetchRequest<Car>(entityName: "Car")
        let sortDescriptor = NSSortDescriptor(key: "brand", ascending: true)
        request.sortDescriptors = [sortDescriptor]
        fetchedResultController = NSFetchedResultsController<Car>(fetchRequest: request,
                                                                  managedObjectContext: CoreDataService.shared.managedObjectContext,
                                                                  sectionNameKeyPath: nil, cacheName: nil)
        
        fetchedResultController.delegate = self
    }
    
    private func loadAllCar() {
        try? fetchedResultController.performFetch()
        if let result = fetchedResultController.fetchedObjects {
            cars = result
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        loadAllCar()
    }
    
    
    
    
    // MARK: - Нереализованное
    
    var isEditModeEnabled: Bool = false {
        didSet {
            editDoneButton.title = isEditModeEnabled ? "Done" : "Edit"
        }
    }
    
    @IBAction func editTable (){
        carsTableView.isEditing = !carsTableView.isEditing
        isEditModeEnabled = !isEditModeEnabled
    }
    
    //delite cell
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return.delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            cars.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .left)
        }
    }
    
    
    // move cell
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
       
        let item = cars[sourceIndexPath.row]
        
        cars.remove(at: sourceIndexPath.row)
        cars.insert(item, at: destinationIndexPath.row)
    }
    
}
