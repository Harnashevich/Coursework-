//
//  CarBrandsFile.swift
//  MyProject
//
//  Created by garnoshevich on 22.09.21.
//

import Foundation

struct Brands: Codable {
    var logo: String
    var name: String
}
