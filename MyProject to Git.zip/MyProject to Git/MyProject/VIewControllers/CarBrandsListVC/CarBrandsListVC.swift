//
//  CarBrandsListVC.swift
//  MyProject
//
//  Created by garnoshevich on 22.09.21.
//

import UIKit

protocol CarBrandsListVCDelegate {
    func sendCarBrand(brand: Brands)
}


final class CarBrandsListVC: UIViewController,
                             UITableViewDataSource,
                             UITableViewDelegate,
                             UISearchBarDelegate {
    
    var delegate: CarBrandsListVCDelegate?
    
    
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var searchBar: UISearchBar!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
        
        loadAllCars()
    }
    
    
    var brands = [Brands]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    var filteredBrands: [Brands] = []
    
    // MARK: - Загрузка изображений и названий брендов
    private func loadAllCars() {
        NetworkServices.loadAllCars { [weak self] brands, error in
            if let brands = brands {
                DispatchQueue.main.async {
                    
                    self?.filteredBrands = brands
                    self?.brands = brands
                    
                }
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
    }
    
    // MARK: - Кнопка отмены
    @IBAction func cancelDidTapped() {
        dismiss(animated: true, completion: nil)
    }
    // MARK: - Инициализация ячеек
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        filteredBrands.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CarBrandCell.identifier,
                                                 for: indexPath) as? CarBrandCell
        
        cell?.setup(car: filteredBrands[indexPath.row])
        
        return cell ?? UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CarBrandCell.rowHeight
    }
    // MARK: - Передача информации при выборе ячейки
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let brand = filteredBrands[indexPath.row]
        delegate?.sendCarBrand(brand: brand)
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: Поисковая строка
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filteredBrands = []
        
        if searchText == "" {
            filteredBrands = brands
        }
        else {
            for brand in brands {
                if brand.name.lowercased().contains(searchText.lowercased()) {
                    filteredBrands.append(brand)
                }
            }
        }
        self.tableView.reloadData()
        
    }
}
