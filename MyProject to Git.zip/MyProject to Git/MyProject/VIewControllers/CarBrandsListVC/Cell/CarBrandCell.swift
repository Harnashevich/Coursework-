//
//  CarBrandCell.swift
//  MyProject
//
//  Created by garnoshevich on 22.09.21.
//

import UIKit

final class CarBrandCell: UITableViewCell {
    
    static let identifier = "CarBrandCell"
    static let rowHeight: CGFloat = 60

    @IBOutlet private weak var logoImageView: UIImageView!
    @IBOutlet private weak var brandLabel: UILabel!
    @IBOutlet private weak var activity: UIActivityIndicatorView!
    
    // MARK: - Загрузка изображений и названий дрендов
    func setup(car: Brands) {
        brandLabel.text = car.name
        loadImage(by: car.logo)
    }
    
    private func loadImage(by url: String) {
        startActivity()
        logoImageView.loadImageUrl(by: url) { [weak self] in
            self?.stopActivity()
        }
    }
    
    private func startActivity() {
        activity.isHidden = false
        activity.startAnimating()
    }
    
    private func stopActivity() {
        activity.isHidden = true
        activity.stopAnimating()
    }

}
