//
//  PartCell.swift
//  MyProject
//
//  Created by garnoshevich on 15.09.21.
//

import UIKit

final class ServiceCell: UITableViewCell {

    static let identifier = "ServiceCell"
    static let rowHeight: CGFloat = 170
    
    @IBOutlet weak var nameServiceLabel: UILabel!
    @IBOutlet weak var mileageNextServiceLabel: UILabel!
    @IBOutlet weak var dateNextServiceLabel: UILabel!
    @IBOutlet weak var cellView: UIView!
    

}
