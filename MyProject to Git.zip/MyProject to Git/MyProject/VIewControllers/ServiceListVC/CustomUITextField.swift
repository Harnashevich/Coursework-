//
//  CustomUITextField.swift
//  MyProject
//
//  Created by garnoshevich on 6.10.21.
//

import Foundation
import UIKit

class CustomUITextField: UITextField {
     func canPerformAction(action: Selector, withSender sender: AnyObject?) -> Bool {
        if action == "paste:" {
            return false
        }
        return super.canPerformAction(action, withSender: sender)
    }
}
