//
//  PartsListVC.swift
//  MyProject
//
//  Created by garnoshevich on 15.09.21.
//

import UIKit
import CoreData


final class ServiceListVC: UIViewController,
                           UITableViewDelegate,
                           UITableViewDataSource,
                           NSFetchedResultsControllerDelegate,
                           UITextFieldDelegate {
    
    @IBOutlet private weak var serviceTableView: UITableView!
    @IBOutlet private weak var carView: UIView!
    @IBOutlet private weak var carImageView: UIImageView!
    @IBOutlet private weak var carBrandLabel: UILabel!
    @IBOutlet private weak var carModelLabel: UILabel!
    @IBOutlet private weak var carYearTextLabel: UILabel!
    @IBOutlet private weak var carMileageTextField: UITextField!
    @IBOutlet private weak var updateStatus: UILabel!
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var updateButton: UIButton!
    
    private var services = [Service]() {
        didSet {
            serviceTableView.reloadData()
        }
    }
    var infoCar: Car!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        serviceTableView.reloadData()
        serviceTableView.delegate = self
        serviceTableView.dataSource = self
        carMileageTextField.delegate = self
        
        setupServiseList()
        setupCarInfo()
        setupFetchedResultController()
        setupDesign()
        
    }
    
    func setupDesign() {
        carView.layer.cornerRadius = carView.frame.height / 6
    }
    
    // MARK: - Ограничение количествва символов
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let maxLength = 6
        let currentString: NSString = carMileageTextField.text! as NSString
        let newString: NSString =
        currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }
    
    // MARK: - Инициализачия ячеек
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        services.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ServiceCell.identifier, for: indexPath) as? ServiceCell  else { return UITableViewCell() }
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "dd MMMM yyyy"
        
        cell.cellView.layer.cornerRadius = cell.cellView.frame.height / 6
        cell.layer.borderColor = UIColor.white.cgColor
        cell.layer.borderWidth = 1
        
        cell.nameServiceLabel.text = services[indexPath.row].nameService
        cell.mileageNextServiceLabel.text = String(services[indexPath.row].mileageNextService)
        cell.dateNextServiceLabel.text = dateformatter.string(from: services[indexPath.row].dateNextService ?? Date())
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ServiceCell.rowHeight
    }
    
    @IBAction func openAddNewService() {
        if let nextVC = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(identifier: "AddNewServiceVC") as? AddNewServiceVC {
            nextVC.carInfo = infoCar
            present(nextVC, animated: true, completion: nil)
        }
    }
    
    // Дейстиве при нажатии на ячейку
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        openInfo(with: services[indexPath.row])
    }
    
    private func openInfo(with service: Service) {
        if let nextVC = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(identifier: "InfoServiceVC") as? InfoServiceVC {
            nextVC.infoService = service
            navigationController?.pushViewController(nextVC, animated: true)
        }
    }
    
    // MARK: - CoreData
    private var fetchedResultController: NSFetchedResultsController<Service>!
    
    private func setupFetchedResultController() {
        let request =  NSFetchRequest<Service>(entityName: "Service")
        let sortDescriptorName = NSSortDescriptor(key: "nameService", ascending: true)
        request.sortDescriptors = [sortDescriptorName]
        fetchedResultController = NSFetchedResultsController<Service>(fetchRequest: request,
                                                                      managedObjectContext: CoreDataService.shared.managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
        
        fetchedResultController.delegate = self
    }
    
    private func loadAllServices() {
        try? fetchedResultController.performFetch()
        if let result = fetchedResultController.fetchedObjects {
            services = result
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        loadAllServices()
    }
    
    // MARK: - Удаление списка
    @IBAction func deleteList()  {
        let alert = UIAlertController(title: "Отчистка списка",
                                      message: "Вы действительн хотите удалить список сервисного обслуживания авто?",
                                      preferredStyle: .actionSheet)
        
        let saveAction = UIAlertAction(title: "Удалить",
                                       style: .destructive) { action in self.clearServices() }
        
        let canselAction = UIAlertAction(title: "Отмена", style: .default) { _ in }
        
        alert.addAction(saveAction)
        alert.addAction(canselAction)
        
        present(alert, animated: true, completion: nil)
    }
    
    func clearServices() {
        let context = CoreDataService.shared.managedObjectContext
        for service in infoCar.services?.allObjects ?? [] {
            if let serviceManegedObject = service as? Service {
                context.delete(serviceManegedObject)
            }
            CoreDataService.shared.saveContext()
        }
        self.serviceTableView.reloadData()
    }
    
    
    func setupCarInfo() {
        //        carImageView.image = infoCar.photo
        carBrandLabel.text = infoCar.brand
        carModelLabel.text = infoCar.model
        carYearTextLabel.text = infoCar.year
        carMileageTextField.text = String(infoCar.mileage)
        
        
        
    }
    
    // MARK: - Сортировка списка
    func setupServiseList() {
        services = infoCar.services?.allObjects as? [Service] ?? []
        services.sort(by: { $0.dateNextService ?? Date() < $1.dateNextService ?? Date() }) // сортировка по следущей дате
//        services.sort(by: { $0.mileageNextService < $1.mileageNextService}) // сортировка по следущему сервису
    }
    
    // MARK: - Методы делегатов
    func textFieldDidBeginEditing(_ textField: UITextField) {
        updateStatus.alpha = 0
        self.carMileageTextField.backgroundColor = .init(cgColor: .init(red: 255/255,
                                                                        green: 255/255,
                                                                        blue: 255/255,
                                                                        alpha: 1))
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        carMileageTextField.resignFirstResponder()
    }
    
    // MARK: - Изменение актуального пробега
    @IBAction func changeMileage(mileage: Car) {
        
        
        self.updateStatus.alpha = 1
        self.updateStatus.text = " ✔︎ Пробег обновлён "
        self.updateStatus.textColor = .white
        self.updateStatus.backgroundColor = .systemGreen
        self.updateStatus.layer.masksToBounds = true
        self.carMileageTextField.backgroundColor = .init(cgColor: .init(red: 214/255,
                                                                        green: 243/255,
                                                                        blue: 194/255,
                                                                        alpha: 0.8))
        self.updateStatus.layer.cornerRadius = 8
        self.view.endEditing(false)
        
        
        guard let mileageStr = carMileageTextField.text,
              let mileage = Int32(mileageStr)
                
        else { return }
        
        infoCar.mileage = mileage
        CoreDataService.shared.saveContext()
    }
    
}


