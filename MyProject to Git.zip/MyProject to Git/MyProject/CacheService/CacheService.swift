//
//  CacheService.swift
//  MyProject
//
//  Created by garnoshevich on 6.10.21.
//

import UIKit

final class CacheService {
    
    static func save(image: UIImage?) -> URL? {
        guard let image = image,
              let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        else { return nil }
        
        let fileName = generateFileName()
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        guard let data = image.jpegData(compressionQuality: 1) else { return nil }
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                try FileManager.default.removeItem(atPath: fileURL.path)
                print("Removed old image")
            } catch let removeError {
                print("couldn't remove file at path", removeError)
                return nil
            }
            
        }
        
        do {
            try data.write(to: fileURL)
        } catch let error {
            print("error saving file with error", error)
            return nil
        }
        return fileURL
    }

    static func loadImageFromDiskWith(url: URL?) -> UIImage? {
        if let imageUrl = url {
            let image = UIImage(contentsOfFile: imageUrl.path)
            return image
        }
        return nil
    }
    
    static private func generateFileName() -> String {
        return "\(Int(Date().timeIntervalSince1970)).jpg"
    }
}
