//
//  NetWorkServices.swift
//  MyProject
//
//  Created by garnoshevich on 22.09.21.
//

import Foundation

final class NetworkServices {

static func loadAllCars(completion: @escaping ([Brands]?, Error?) -> Void) {
    guard let url = URL(string: "https://gist.githubusercontent.com/shcyiza/71c64a33f3880e58980003c4c794db38/raw/febb04707f6ccc9ae3a445e147c5754e30f743fe/car_brands.json") else { return }
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    
    URLSession.shared.dataTask(with: request) { responseData, response, error in
        if let data = responseData {
            let cars = try? JSONDecoder().decode([Brands].self, from: data)
            completion(cars, error)
        } else {
            completion(nil, error)
        }
    }.resume()
}

}
